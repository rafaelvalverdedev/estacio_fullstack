const db = require('../db');
(async () => {
  try {
    await db.schema.dropTableIfExists('country')
    await db.schema.createTable('country', (table) => {
      table.increments()
      table.string('name')
      table.string('capital')
      table.string('currency')
      table.integer('population')
    })
    console.log('Created country table!')
    process.exit(0)
  } catch (err) {
    console.log(err)
    process.exit(1)
  }
})()