const db = require('../db');
(async () => {
  try {
    await db('country').insert({ name: 'Spain', capital: 'Madrid', currency: 'EUR', population: 46704314 })
    await db('country').insert({ name: 'Poland', capital: 'Warsaw', currency: 'PLN', population: 38186860 })
    await db('country').insert({ name: 'United Kingdom', capital: 'London', currency: 'GBP', population: 63705000 })
    console.log('Added countries!')
    process.exit(0)
  } catch (err) {
    console.log(err)
    process.exit(1)
  }
})()