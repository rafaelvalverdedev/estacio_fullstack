const fastify = require('fastify')({ logger: true })

//Seta, a partir das variaveis de ambiente, algumas constantes.
//  Essas constantes se referem a instrucoes do fastify que sao diferentes
//    entre o Postgresql e o MySql
const db_driver = process.env.FASTIFY_DB_DRIVER
const db_dialect = process.env.FASTIFY_DB_DIALECT
const db_query_params = process.env.FASTIFY_DB_QUERY_PARAMS

//Registra a lib @fastify/postgres para ser usada no fastify
fastify.register(require(`@fastify/${db_driver}`), {
  connectionString: `${db_driver}://${process.env.DB_USER}:${process.env.DB_PASS}@${process.env.DB_HOST}/${process.env.DB_NAME}`
})

fastify.register(require("@fastify/cors"), {
  origin: "*",
  methods: ["POST", "GET", "PUT", "DELETE"]
});

//Define um endpoint GET para a busca de pais pelo id
fastify.get('/country/:id', function (req, reply) {
  fastify[db_dialect].query(
    `SELECT id, name, capital, currency, population FROM country WHERE id=${db_query_params}`, [req.params.id],
    function onResult (err, result) {
      console.log(result);
      reply.send(err || result.rows || result)
    }
  )
})

//Define um endpoint GET para a listagem de todos os paises cadastrados
fastify.get('/country', function (req, reply) {
  fastify[db_dialect].query(
    `SELECT id, name, capital, currency, population FROM country `,
    function onResult (err, result) {
      reply.send(err || result.rows || result)
    }
  )
})

//Define um endpoint GET a raiz da API, retornando apenas um 'hello world'
fastify.get('/', function (request, reply) {
    reply.send({ hello: 'world' })
})

//Configura o fastify para ouvir na porta 3000 e responder em qualquer host
fastify.listen({ port: 3000, host: '0.0.0.0' }, (err, address) => {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    console.info(`Server listening on port ${address}`);
});