import { useState, useEffect } from "react";
import Container from "react-bootstrap/Container";
import Table from "react-bootstrap/Table";
import AxiosInstance from "../../api/AxiosInstance";
import Navbar from "react-bootstrap/Navbar";

const Home = () => {
  const [country, setCountry] = useState([]);
  const [isLoading, setLoading] = useState(false);

  useEffect(() => {
    getCountries();
  }, []);

  const getCountries = async () => {
    AxiosInstance.get(`/country`)
      .then((result) => {
        console.log("countries: " + JSON.stringify(result.data));
        setCountry(result.data);
        setLoading(true);
      })
      .catch(function (error) {
        console.log("Erro no getCountries: " + error.toJSON());
      });
  };

  return (
    <Container className="p-3">
      <Navbar bg="primary p-3 mb-5">
        <Navbar.Brand>Menu</Navbar.Brand>
      </Navbar>
      {isLoading && (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Nome</th>
              <th>Capital</th>
              <th>Moeda</th>
              <th>População</th>
            </tr>
          </thead>
          <tbody>
            {country.map((k, i) => (
              <tr>
                <td>{k.id}</td>
                <td>{k.name}</td>
                <td>{k.capital}</td>
                <td>{k.currency}</td>
                <td>{k.population}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Container>
  );
};

export default Home;