import axios from 'axios';

const AxiosInstance = axios.create({
  baseURL: "http://192.168.220.128:3099",
});

export default AxiosInstance;